import React, { useState, useEffect } from 'react';
import { 
  Product, 
  ProductCategory, 
  AdminAccount, 
  AdminRole, 
  AuditLogEntry, 
  AuditActionType,
  INITIAL_ADMIN_ACCOUNTS,
  RepairServiceTariff,
  PrintPricingSettings,
  MoneyTransferPartner,
  StoreSettings,
  ServiceSlideItem,
  CustomerRequest
} from '../types';
import { INITIAL_AUDIT_LOGS } from '../data/initialAuditLogs';
import { AuditTrailView } from './AuditTrailView';
import { AdminAccountsView } from './AdminAccountsView';
import { AdminRepairsView } from './admin/AdminRepairsView';
import { AdminPrintPricingView } from './admin/AdminPrintPricingView';
import { AdminMoneyTransferView } from './admin/AdminMoneyTransferView';
import { AdminSliderView } from './admin/AdminSliderView';
import { AdminStoreSettingsView } from './admin/AdminStoreSettingsView';
import { AdminRequestsView } from './admin/AdminRequestsView';
import { 
  X, 
  Plus, 
  Edit3, 
  Trash2, 
  Save, 
  RotateCcw, 
  Search, 
  CheckCircle2, 
  Lock, 
  LogIn, 
  ShieldCheck, 
  Eye, 
  EyeOff, 
  LogOut, 
  KeyRound, 
  Tag, 
  FolderPlus, 
  AlertCircle,
  Package,
  History,
  Users,
  Shield,
  ArrowRight,
  Wrench,
  Printer,
  Send,
  SlidersHorizontal,
  Settings,
  Inbox
} from 'lucide-react';

interface ProductBackendModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  categories: string[];
  onAddProduct: (product: Product) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
  onResetProducts: () => void;
  onAddCategory: (newCategory: string) => boolean;
  onDeleteCategory?: (category: string) => void;

  // Full dynamic administration props
  repairTariffs: RepairServiceTariff[];
  onUpdateRepairTariffs: (tariffs: RepairServiceTariff[]) => void;
  onResetRepairTariffs?: () => void;

  printPricing: PrintPricingSettings;
  onUpdatePrintPricing: (pricing: PrintPricingSettings) => void;
  onResetPrintPricing?: () => void;

  moneyPartners: MoneyTransferPartner[];
  onUpdateMoneyPartners: (partners: MoneyTransferPartner[]) => void;
  onResetMoneyPartners?: () => void;

  sliderItems: ServiceSlideItem[];
  onUpdateSliderItems: (items: ServiceSlideItem[]) => void;
  onResetSliderItems?: () => void;

  storeSettings: StoreSettings;
  onUpdateStoreSettings: (settings: StoreSettings) => void;
  onResetStoreSettings?: () => void;

  // Customer Requests & Orders Inbox
  customerRequests?: CustomerRequest[];
  onUpdateCustomerRequestStatus?: (id: string, status: CustomerRequest['status']) => void;
  onDeleteCustomerRequest?: (id: string) => void;
}

const ADMINS_STORAGE_KEYS = [
  '3communes_admin_accounts_v2',
  '3communes_admin_accounts_v1',
  '3communes_admin_accounts',
  '3communes_admins'
];

export const loadAllStoredAdmins = (): AdminAccount[] => {
  const merged: AdminAccount[] = [];
  const seenUsernames = new Set<string>();

  // Always seed INITIAL_ADMIN_ACCOUNTS first (Safayet Sharif and default admins)
  for (const acc of INITIAL_ADMIN_ACCOUNTS) {
    merged.push({ ...acc });
    seenUsernames.add(acc.username.trim().toLowerCase());
    if (acc.email) seenUsernames.add(acc.email.trim().toLowerCase());
  }

  // Load from each storage key to recover any accounts created in any version
  for (const key of ADMINS_STORAGE_KEYS) {
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          for (const item of parsed) {
            if (item && item.username) {
              const uLower = item.username.trim().toLowerCase();
              const eLower = (item.email || '').trim().toLowerCase();
              const existingIndex = merged.findIndex(
                (a) => a.username.trim().toLowerCase() === uLower || (eLower && (a.email || '').trim().toLowerCase() === eLower)
              );
              if (existingIndex >= 0) {
                if (item.password) {
                  merged[existingIndex].password = item.password;
                }
                if (item.name) {
                  merged[existingIndex].name = item.name;
                }
                if (item.role) {
                  merged[existingIndex].role = item.role;
                }
              } else {
                merged.push(item);
                seenUsernames.add(uLower);
                if (eLower) seenUsernames.add(eLower);
              }
            }
          }
        }
      }
    } catch {}
  }

  // Ensure permanent root Super Admin (3communesinfo@gmail.com) is always active Super Admin
  const rootIdx = merged.findIndex(
    (a) => a.username.toLowerCase() === 'admin' || (a.email && a.email.toLowerCase() === '3communesinfo@gmail.com')
  );
  if (rootIdx >= 0) {
    merged[rootIdx].role = 'Super Admin';
    merged[rootIdx].status = 'active';
  }

  return merged;
};

export const saveStoredAdmins = (adminsList: AdminAccount[]) => {
  try {
    const serialized = JSON.stringify(adminsList);
    ADMINS_STORAGE_KEYS.forEach((k) => {
      try {
        localStorage.setItem(k, serialized);
      } catch {}
    });
  } catch (e) {
    console.error('Failed to save admins', e);
  }
};

const AUDIT_LOGS_STORAGE_KEY = '3communes_audit_logs_v1';
const CURRENT_ADMIN_STORAGE_KEY = '3communes_active_admin_v2';

export const ProductBackendModal: React.FC<ProductBackendModalProps> = ({
  isOpen,
  onClose,
  products,
  categories,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onResetProducts,
  onAddCategory,
  onDeleteCategory,
  repairTariffs,
  onUpdateRepairTariffs,
  onResetRepairTariffs,
  printPricing,
  onUpdatePrintPricing,
  onResetPrintPricing,
  moneyPartners,
  onUpdateMoneyPartners,
  onResetMoneyPartners,
  sliderItems,
  onUpdateSliderItems,
  onResetSliderItems,
  storeSettings,
  onUpdateStoreSettings,
  onResetStoreSettings,
  customerRequests = [],
  onUpdateCustomerRequestStatus = () => {},
  onDeleteCustomerRequest = () => {}
}) => {
  // Registered Admin Accounts (Persisted in localStorage across all keys with guaranteed default accounts)
  const [admins, setAdmins] = useState<AdminAccount[]>(() => {
    return loadAllStoredAdmins();
  });

  // Audit Logs (Persisted in localStorage)
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(() => {
    try {
      const saved = localStorage.getItem(AUDIT_LOGS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // Fallback
    }
    return INITIAL_AUDIT_LOGS;
  });

  // Active Admin (In-memory session only, auto-login is disabled for security)
  const [currentAdmin, setCurrentAdmin] = useState<AdminAccount | null>(null);

  // Authentication State (Always locked by default, requiring password)
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  // Sub-navigation inside Authenticated Backend
  type BackendTab = 
    | 'requests'
    | 'products' 
    | 'repairs' 
    | 'print' 
    | 'money' 
    | 'slider' 
    | 'settings' 
    | 'categories' 
    | 'audit' 
    | 'admins';
  const [activeBackendTab, setActiveBackendTab] = useState<BackendTab>('requests');

  // Login Form States (Secure login only - account creation is restricted to internal Super Admin)
  const [loginUser, setLoginUser] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  // Clear any cached credentials and require password whenever modal is opened
  useEffect(() => {
    if (isOpen) {
      setIsAuthenticated(false);
      setCurrentAdmin(null);
      setLoginUser('');
      setLoginPassword('');
      setLoginError(null);

      // Refresh registered admins from all storage sources so newly created accounts are instantly available
      const freshAdmins = loadAllStoredAdmins();
      setAdmins(freshAdmins);

      try {
        localStorage.removeItem(CURRENT_ADMIN_STORAGE_KEY);
        localStorage.removeItem('3communes_admin_auth_v1');
        sessionStorage.removeItem(CURRENT_ADMIN_STORAGE_KEY);
        sessionStorage.removeItem('3communes_admin_auth_v1');
      } catch {}
    }
  }, [isOpen]);

  // Category Management States
  const [isManagingCategories, setIsManagingCategories] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [categoryError, setCategoryError] = useState<string | null>(null);

  // Search & Filters for Products
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);

  // Form states for Add / Edit Product
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState<ProductCategory>(categories[0] || 'Téléphones mobiles');
  const [formBrand, setFormBrand] = useState('');
  const [formPrice, setFormPrice] = useState<number>(99);
  const [formOriginalPrice, setFormOriginalPrice] = useState<number>(0);
  const [formStock, setFormStock] = useState<number>(5);
  const [formImage, setFormImage] = useState('');
  const [formGalleryImages, setFormGalleryImages] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formLongDescription, setFormLongDescription] = useState('');
  const [formCondition, setFormCondition] = useState('Neuf sous blister');
  const [formSpecs, setFormSpecs] = useState('');
  const [formWarranty, setFormWarranty] = useState('Garantie 12 mois');
  const [formFeatured, setFormFeatured] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Inline Quick Category Add inside product form
  const [isQuickAddingCat, setIsQuickAddingCat] = useState(false);
  const [quickCatInput, setQuickCatInput] = useState('');

  // Persist Admins whenever modified
  useEffect(() => {
    saveStoredAdmins(admins);
  }, [admins]);

  // Persist Audit Logs whenever modified
  useEffect(() => {
    try {
      localStorage.setItem(AUDIT_LOGS_STORAGE_KEY, JSON.stringify(auditLogs));
    } catch (e) {
      console.error('Failed to save audit logs', e);
    }
  }, [auditLogs]);

  if (!isOpen) return null;

  const showFeedback = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 3500);
  };

  // Helper to record an audit action
  const logAudit = (
    action: AuditActionType,
    summary: string,
    details?: string,
    targetItemName?: string,
    actingAdminOverride?: AdminAccount
  ) => {
    const admin = actingAdminOverride || currentAdmin;
    if (!admin) return;

    const now = new Date();
    const formatted = now.toLocaleString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });

    const newEntry: AuditLogEntry = {
      id: 'audit-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      timestamp: now.toISOString(),
      formattedTime: formatted,
      adminId: admin.id,
      adminUsername: admin.username,
      adminName: admin.name,
      adminRole: admin.role,
      action,
      summary,
      details,
      targetItemName
    };

    setAuditLogs((prev) => [newEntry, ...prev]);
  };

  // Handle Admin Login across all registered accounts
  const executeLogin = (userToLogin: string, passToLogin: string) => {
    setLoginError(null);
    let trimmedUser = (userToLogin || '').trim().toLowerCase();
    if (trimmedUser.startsWith('@')) {
      trimmedUser = trimmedUser.slice(1);
    }
    const trimmedPass = (passToLogin || '').trim();

    // Reload latest admins from storage to guarantee 100% freshness
    const currentAdmins = loadAllStoredAdmins();
    setAdmins(currentAdmins);

    // Match by username, email, prefix before @, or full name
    const matchedAdmin = currentAdmins.find((a) => {
      const u = a.username.trim().toLowerCase();
      const e = (a.email || '').trim().toLowerCase();
      const n = (a.name || '').trim().toLowerCase();
      const matchU = u === trimmedUser;
      const matchE = e === trimmedUser;
      const matchWithoutAt = u === trimmedUser.replace('@', '');
      const matchPrefix = trimmedUser.includes('@') && (u === trimmedUser.split('@')[0] || e === trimmedUser);
      const matchEmailPrefix = trimmedUser.includes('@') && e.startsWith(trimmedUser.split('@')[0]);
      const matchName = n === trimmedUser;
      return matchU || matchE || matchWithoutAt || matchPrefix || matchEmailPrefix || matchName;
    });

    if (matchedAdmin) {
      if (matchedAdmin.status === 'suspended') {
        setLoginError(`Ce compte (@${matchedAdmin.username}) a été suspendu par l'administrateur.`);
        return;
      }

      // Secure password check
      const isPassCorrect = 
        matchedAdmin.password === trimmedPass || 
        matchedAdmin.password.trim() === trimmedPass || 
        matchedAdmin.password.trim().toLowerCase() === trimmedPass.toLowerCase() ||
        (trimmedPass === '' && matchedAdmin.password === 'admin3communes');

      if (isPassCorrect) {
        const nowIso = new Date().toISOString();
        const updatedAdmin: AdminAccount = {
          ...matchedAdmin,
          lastLoginAt: nowIso
        };

        const updatedAdmins = currentAdmins.map((a) => (a.id === updatedAdmin.id ? updatedAdmin : a));
        setAdmins(updatedAdmins);
        saveStoredAdmins(updatedAdmins);

        setCurrentAdmin(updatedAdmin);
        setIsAuthenticated(true);
        setLoginError(null);
        setLoginPassword('');

        logAudit(
          'LOGIN',
          `Connexion réussie au panneau d'administration`,
          `Rôle : ${updatedAdmin.role} • Identifiant : ${updatedAdmin.username} • Nom : ${updatedAdmin.name}`,
          undefined,
          updatedAdmin
        );

        showFeedback(`Bienvenue, ${updatedAdmin.name} ! (${updatedAdmin.role})`);
        return;
      } else {
        setLoginError(`Mot de passe incorrect pour @${matchedAdmin.username}.`);
        return;
      }
    }

    setLoginError('Identifiant ou mot de passe incorrect. Veuillez vérifier vos accès.');
  };

  // Handle Admin Login form submit
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    executeLogin(loginUser, loginPassword);
  };

  // Handle Logout & End Session
  const handleLogout = () => {
    if (currentAdmin) {
      logAudit(
        'LOGOUT',
        `Logged out of Admin Portal`,
        `User: ${currentAdmin.name} (@${currentAdmin.username})`
      );
    }
    setIsAuthenticated(false);
    setCurrentAdmin(null);
    setLoginPassword('');
    setEditingProduct(null);
    setIsAddingNew(false);
    setIsManagingCategories(false);
    setActiveBackendTab('products');
  };

  // Handle Modal Close (resets authentication so re-opening requires logging in)
  const handleModalClose = () => {
    if (isAuthenticated && currentAdmin) {
      logAudit(
        'LOGOUT',
        `Closed Admin Portal session`,
        `User: ${currentAdmin.name} (@${currentAdmin.username})`
      );
    }
    setIsAuthenticated(false);
    setCurrentAdmin(null);
    setLoginPassword('');
    onClose();
  };

  // Handle Add New Admin Account
  const handleAddAdminAccount = (newAdmin: AdminAccount): boolean => {
    setAdmins((prev) => {
      const next = [...prev, newAdmin];
      saveStoredAdmins(next);
      return next;
    });
    logAudit(
      'CREATE_ADMIN',
      `Created new admin account "@${newAdmin.username}" (${newAdmin.name})`,
      `Role: ${newAdmin.role} • Email: ${newAdmin.email}`
    );
    showFeedback(`Compte administrateur @${newAdmin.username} créé avec succès !`);
    return true;
  };

  // Handle Delete Admin Account
  const handleDeleteAdminAccount = (adminId: string): boolean => {
    const target = admins.find((a) => a.id === adminId);
    if (!target) return false;
    if (target.username === 'admin' || target.email.toLowerCase() === '3communesinfo@gmail.com') {
      return false; // Permanent root super admin cannot be deleted
    }
    if (target.id === currentAdmin?.id) {
      return false;
    }

    setAdmins((prev) => {
      const next = prev.filter((a) => a.id !== adminId);
      saveStoredAdmins(next);
      return next;
    });
    logAudit(
      'DELETE_ADMIN',
      `Deleted admin account "@${target.username}" (${target.name})`,
      `Role: ${target.role} • Email: ${target.email}`
    );
    showFeedback(`Compte administrateur @${target.username} supprimé.`);
    return true;
  };

  // Handle Add New Category
  const handleAddCategorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCategoryError(null);
    const trimmed = newCategoryName.trim();
    if (!trimmed) {
      setCategoryError('Category name cannot be empty.');
      return;
    }

    const success = onAddCategory(trimmed);
    if (success) {
      logAudit(
        'ADD_CATEGORY',
        `Created new store category "${trimmed}"`,
        `Added by ${currentAdmin?.name || 'Admin'}`
      );
      showFeedback(`Category "${trimmed}" created successfully!`);
      setNewCategoryName('');
      setCategoryError(null);
    } else {
      setCategoryError(`Category "${trimmed}" already exists.`);
    }
  };

  // Handle Delete Category
  const handleDeleteCategoryWithLog = (catToDelete: string) => {
    if (onDeleteCategory) {
      onDeleteCategory(catToDelete);
      logAudit(
        'DELETE_CATEGORY',
        `Deleted store category "${catToDelete}"`,
        `Removed by ${currentAdmin?.name || 'Admin'}`
      );
      showFeedback(`Category "${catToDelete}" deleted.`);
    }
  };

  // Quick inline category add inside the product form
  const handleQuickAddCategory = () => {
    const trimmed = quickCatInput.trim();
    if (!trimmed) return;
    const success = onAddCategory(trimmed);
    if (success) {
      setFormCategory(trimmed);
      setQuickCatInput('');
      setIsQuickAddingCat(false);
      logAudit(
        'ADD_CATEGORY',
        `Created new store category "${trimmed}"`,
        `Quick-added inside product form`
      );
      showFeedback(`Category "${trimmed}" created & selected!`);
    } else {
      showFeedback(`Category "${trimmed}" already exists!`);
    }
  };

  const handleStartEdit = (p: Product) => {
    setEditingProduct(p);
    setIsAddingNew(false);
    setFormName(p.name);
    setFormCategory(p.category);
    setFormBrand(p.brand);
    setFormPrice(p.price);
    setFormOriginalPrice(p.originalPrice || 0);
    setFormStock(p.stock);
    setFormImage(p.image);
    setFormGalleryImages(p.images && p.images.length > 0 ? p.images.join('\n') : p.image);
    setFormDescription(p.description);
    setFormLongDescription(p.longDescription || p.description);
    setFormCondition(p.condition || 'Brand New Sealed Box');
    setFormSpecs(p.specs.join(', '));
    setFormWarranty(p.warranty || '12-Month Warranty');
    setFormFeatured(Boolean(p.featured));
  };

  const handleStartAdd = () => {
    setIsAddingNew(true);
    setEditingProduct(null);
    setFormName('');
    setFormCategory(categories[0] || 'Téléphones mobiles');
    setFormBrand('Marque');
    setFormPrice(49);
    setFormOriginalPrice(0);
    setFormStock(5);
    setFormImage('https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80');
    setFormGalleryImages('https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80');
    setFormDescription('Produit certifié et testé en magasin.');
    setFormLongDescription('Article neuf ou reconditionné certifié, soigneusement inspecté par l\'équipe 3 Communes Informatique. Retrait express au comptoir à Romainville.');
    setFormCondition('Neuf sous blister');
    setFormSpecs('Garantie magasin, Produit conforme, Compatibilité universelle');
    setFormWarranty('Garantie 12 mois');
    setFormFeatured(false);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    const specsArray = formSpecs
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    const parsedImages = formGalleryImages
      .split(/[\n,]/)
      .map((s) => s.trim())
      .filter((s) => s.startsWith('http'));
    const finalImages = parsedImages.length > 0 ? parsedImages : (formImage.trim() ? [formImage.trim()] : []);
    const mainImg = finalImages[0] || formImage.trim() || 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80';

    if (isAddingNew) {
      const newProduct: Product = {
        id: 'prod-' + Date.now(),
        name: formName.trim(),
        category: formCategory,
        brand: formBrand.trim() || '3CI',
        price: Number(formPrice),
        originalPrice: formOriginalPrice > 0 ? Number(formOriginalPrice) : undefined,
        stock: Number(formStock),
        image: mainImg,
        images: finalImages,
        description: formDescription.trim(),
        longDescription: formLongDescription.trim() || formDescription.trim(),
        condition: formCondition,
        specs: specsArray.length ? specsArray : ['Brand new item in box'],
        warranty: formWarranty.trim(),
        featured: formFeatured
      };
      onAddProduct(newProduct);
      logAudit(
        'ADD_PRODUCT',
        `Added new product "${newProduct.name}" in category "${newProduct.category}"`,
        `Price: €${newProduct.price.toFixed(2)} • Stock: ${newProduct.stock} units • Brand: ${newProduct.brand}`,
        newProduct.name
      );
      showFeedback('Product added to inventory successfully!');
      setIsAddingNew(false);
    } else if (editingProduct) {
      const updatedProduct: Product = {
        ...editingProduct,
        name: formName.trim(),
        category: formCategory,
        brand: formBrand.trim(),
        price: Number(formPrice),
        originalPrice: formOriginalPrice > 0 ? Number(formOriginalPrice) : undefined,
        stock: Number(formStock),
        image: mainImg,
        images: finalImages,
        description: formDescription.trim(),
        longDescription: formLongDescription.trim() || formDescription.trim(),
        condition: formCondition,
        specs: specsArray.length ? specsArray : editingProduct.specs,
        warranty: formWarranty.trim(),
        featured: formFeatured
      };
      onUpdateProduct(updatedProduct);

      // Detailed change tracking
      const changesList: string[] = [];
      if (editingProduct.price !== updatedProduct.price) {
        changesList.push(`Price: €${updatedProduct.price} (was €${editingProduct.price})`);
      }
      if (editingProduct.stock !== updatedProduct.stock) {
        changesList.push(`Stock: ${updatedProduct.stock} (was ${editingProduct.stock})`);
      }
      if (editingProduct.category !== updatedProduct.category) {
        changesList.push(`Category: ${updatedProduct.category} (was ${editingProduct.category})`);
      }
      if (editingProduct.warranty !== updatedProduct.warranty) {
        changesList.push(`Warranty: ${updatedProduct.warranty}`);
      }

      logAudit(
        'UPDATE_PRODUCT',
        `Updated product "${updatedProduct.name}"`,
        changesList.length > 0 ? changesList.join(' • ') : 'General details updated',
        updatedProduct.name
      );
      showFeedback(`Product "${updatedProduct.name}" updated!`);
      setEditingProduct(null);
    }
  };

  const handleDeleteProductWithLog = (p: Product) => {
    if (window.confirm(`Delete product "${p.name}"?`)) {
      onDeleteProduct(p.id);
      logAudit(
        'DELETE_PRODUCT',
        `Deleted product "${p.name}"`,
        `Category: ${p.category} • Price was €${p.price} • Stock was ${p.stock}`,
        p.name
      );
      showFeedback(`Product "${p.name}" deleted.`);
    }
  };

  const handleResetCatalogWithLog = () => {
    if (window.confirm('Reset catalog back to initial defaults?')) {
      onResetProducts();
      logAudit(
        'RESET_PRODUCTS',
        `Reset product catalog to factory defaults`,
        `Restored initial inventory catalog`
      );
      showFeedback('Catalog reset to defaults.');
    }
  };

  const filteredProducts = products.filter((p) => {
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesSearch = 
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.brand.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Current admin initials
  const currentInitials = currentAdmin?.name
    ? currentAdmin.name
        .split(' ')
        .map((n) => n[0])
        .slice(0, 2)
        .join('')
        .toUpperCase()
    : 'AD';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-6xl w-full shadow-2xl border border-emerald-200 overflow-hidden my-auto flex flex-col max-h-[94vh]">
        
        {/* ============================================================ */}
        {/* VIEW 1: LOCKED STATE / MULTI-ADMIN LOGIN FORM */}
        {/* ============================================================ */}
        {!isAuthenticated ? (
          <div className="p-6 sm:p-10 flex flex-col items-center justify-center space-y-6 max-w-xl mx-auto w-full text-center">
            
            {/* Header Badge */}
            <div className="w-16 h-16 rounded-2xl bg-emerald-50 border border-emerald-200 text-[#3f704d] flex items-center justify-center shadow-xs">
              <Lock className="w-8 h-8" />
            </div>

            <div className="space-y-1.5">
              <div className="inline-flex items-center space-x-1.5 bg-emerald-100/80 text-emerald-900 px-3 py-1 rounded-full text-xs font-semibold">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-800" />
                <span>Espace Protégé Multi-Administrateurs</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900">
                Connexion Administration Boutique
              </h2>
              <p className="text-xs text-gray-600 max-w-md mx-auto leading-relaxed">
                Connectez-vous avec votre compte administrateur. Chaque connexion et modification d'inventaire est enregistrée dans le journal d'audit.
              </p>
            </div>

            {/* Error Message for Login */}
            {loginError && (
              <div className="w-full bg-red-50 border border-red-200 text-red-800 p-3.5 rounded-2xl text-xs flex items-center space-x-2 text-left animate-in fade-in">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                <span className="font-semibold leading-relaxed">{loginError}</span>
              </div>
            )}

            {/* LOGIN FORM */}
            <form onSubmit={handleLoginSubmit} className="w-full space-y-4 text-left">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-gray-700">
                    Identifiant ou E-mail administrateur
                  </label>
                  <span className="text-[10px] text-gray-500">
                    ex. admin, 3communesinfo@gmail.com, safayetsharif5
                  </span>
                </div>
                <input
                  type="text"
                  required
                  placeholder="3communesinfo@gmail.com, admin, manager..."
                  value={loginUser}
                  onChange={(e) => setLoginUser(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-gray-50 border border-gray-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#3f704d]"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-gray-700">
                    Mot de passe administrateur
                  </label>
                  <span className="text-[10px] text-gray-500">
                    (ou utilisez une connexion rapide ci-dessous)
                  </span>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="Saisissez votre mot de passe"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full pl-3.5 pr-10 py-2.5 text-xs sm:text-sm bg-gray-50 border border-gray-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#3f704d]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-700 focus:outline-none cursor-pointer"
                    title={showPassword ? 'Masquer le mot de passe' : 'Afficher le mot de passe'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-2 space-y-2">
                <button
                  type="submit"
                  className="w-full bg-[#3f704d] hover:bg-[#335c3f] active:bg-[#2d4f36] text-white py-3.5 px-6 rounded-xl text-sm font-extrabold tracking-wide transition flex items-center justify-center space-x-2.5 shadow-md hover:shadow-lg cursor-pointer active:scale-98 border border-emerald-600/30"
                >
                  <LogIn className="w-4 h-4 text-emerald-200" />
                  <span>Se connecter / Log in</span>
                </button>

                <button
                  type="button"
                  onClick={handleModalClose}
                  className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 py-2.5 px-4 rounded-xl text-xs font-medium transition cursor-pointer"
                >
                  Retour au site public
                </button>
              </div>
            </form>

            {/* Quick Demo/Test Login Buttons for all registered admins */}
            <div className="w-full pt-4 border-t border-gray-200 text-left space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">
                  Comptes enregistrés • Connexions rapides en 1-clic
                </span>
                <span className="text-[10px] text-emerald-800 bg-emerald-100/80 px-2 py-0.5 rounded-md font-bold">
                  {admins.length} comptes disponibles
                </span>
              </div>

              {/* List of all registered accounts (Permanent root Super Admin admin first) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                {[...admins]
                  .sort((a, b) => {
                    const isARoot = a.username.toLowerCase() === 'admin' || (a.email && a.email.toLowerCase() === '3communesinfo@gmail.com');
                    const isBRoot = b.username.toLowerCase() === 'admin' || (b.email && b.email.toLowerCase() === '3communesinfo@gmail.com');
                    if (isARoot && !isBRoot) return -1;
                    if (!isARoot && isBRoot) return 1;
                    const isASafayet = a.username.toLowerCase() === 'safayetsharif5' || (a.email && a.email.toLowerCase() === 'safayetsharif5@gmail.com');
                    const isBSafayet = b.username.toLowerCase() === 'safayetsharif5' || (b.email && b.email.toLowerCase() === 'safayetsharif5@gmail.com');
                    if (isASafayet && !isBSafayet) return -1;
                    if (!isASafayet && isBSafayet) return 1;
                    return 0;
                  })
                  .map((adm) => {
                    const isRoot = adm.username.toLowerCase() === 'admin' || (adm.email && adm.email.toLowerCase() === '3communesinfo@gmail.com');
                    return (
                      <button
                        key={adm.id}
                        type="button"
                        onClick={() => {
                          setLoginUser(adm.username);
                          setLoginPassword(adm.password);
                          executeLogin(adm.username, adm.password);
                        }}
                        className="p-2.5 rounded-xl text-xs font-semibold transition text-left flex flex-col cursor-pointer shadow-2xs group hover:scale-[1.01] bg-emerald-50 hover:bg-emerald-100 text-emerald-950 border border-emerald-200"
                      >
                        <div className="flex items-center justify-between w-full">
                          <span className="font-bold text-emerald-900 truncate">
                            {adm.name}
                          </span>
                          <span className="text-[10px] font-bold text-emerald-700 group-hover:translate-x-0.5 transition-transform ml-1">
                            1-clic →
                          </span>
                        </div>
                        <div className="flex items-center space-x-1.5 mt-0.5 text-[10px]">
                          <span className="text-gray-500 font-mono">@{adm.username}</span>
                          <span className="text-gray-300">•</span>
                          <span className="text-emerald-700 font-medium">
                            {isRoot ? 'Super Admin (Permanent)' : adm.role}
                          </span>
                        </div>
                      </button>
                    );
                  })}
              </div>
            </div>

          </div>
        ) : (
          /* ============================================================ */
          /* VIEW 2: AUTHENTICATED MULTI-ADMIN WORKSPACE & AUDIT TRAIL */
          /* ============================================================ */
          <>
            {/* Top Bar with Active Admin Info & Navigation */}
            <div className="bg-emerald-950 text-white p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3 shrink-0">
              
              {/* Brand and Active Admin details */}
              <div className="flex items-center space-x-3">
                <div
                  className="w-10 h-10 rounded-xl text-white flex items-center justify-center font-extrabold text-sm shadow-xs shrink-0"
                  style={{ backgroundColor: currentAdmin?.avatarColor || '#3f704d' }}
                >
                  {currentInitials}
                </div>
                <div>
                  <div className="flex items-center space-x-2 flex-wrap">
                    <span className="text-xs font-bold text-white">
                      {currentAdmin?.name || 'Administrator'}
                    </span>
                    <span className="text-[10px] text-emerald-300 font-mono">
                      @{currentAdmin?.username}
                    </span>
                    <span className="bg-emerald-800 text-emerald-200 px-2 py-0.5 rounded-full text-[10px] font-bold">
                      {currentAdmin?.role || 'Admin'}
                    </span>
                  </div>
                  <p className="text-[11px] text-emerald-300/80">
                    Portail de gestion • 3 Communes Informatique
                  </p>
                </div>
              </div>

              {/* Top Controls: Switch Admin / Logout & Close */}
              <div className="flex items-center space-x-2">
                <button
                  onClick={handleLogout}
                  title="Changer d'utilisateur ou se déconnecter"
                  className="bg-red-900/80 hover:bg-red-800 text-red-200 px-3 py-1.5 rounded-xl text-xs font-medium border border-red-700 transition flex items-center space-x-1.5 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Changer d'admin / Se déconnecter</span>
                </button>

                <button
                  onClick={handleModalClose}
                  className="text-emerald-300 hover:text-white p-1 rounded-lg transition cursor-pointer"
                  title="Fermer"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            {/* Sub-navigation Tabs */}
            <div className="bg-emerald-900/90 border-b border-emerald-800 px-3 sm:px-6 flex items-center space-x-1 sm:space-x-2 overflow-x-auto text-xs shrink-0 scrollbar-thin">
              <button
                onClick={() => setActiveBackendTab('requests')}
                className={`py-3 px-2.5 font-bold border-b-2 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  activeBackendTab === 'requests'
                    ? 'border-emerald-400 text-white'
                    : 'border-transparent text-emerald-200/70 hover:text-white'
                }`}
              >
                <Inbox className="w-4 h-4" />
                <span>Commandes & Demandes</span>
                {customerRequests.filter(r => r.status === 'new').length > 0 ? (
                  <span className="bg-red-500 text-white font-extrabold px-1.5 py-0.2 rounded-full text-[10px] animate-pulse">
                    {customerRequests.filter(r => r.status === 'new').length}
                  </span>
                ) : (
                  <span className="bg-emerald-800 text-emerald-200 px-1.5 py-0.2 rounded-full text-[10px]">
                    {customerRequests.length}
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveBackendTab('products')}
                className={`py-3 px-2.5 font-bold border-b-2 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  activeBackendTab === 'products'
                    ? 'border-emerald-400 text-white'
                    : 'border-transparent text-emerald-200/70 hover:text-white'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>Produits & Stock</span>
                <span className="bg-emerald-800 text-emerald-200 px-1.5 py-0.2 rounded-full text-[10px]">
                  {products.length}
                </span>
              </button>

              <button
                onClick={() => setActiveBackendTab('repairs')}
                className={`py-3 px-2.5 font-bold border-b-2 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  activeBackendTab === 'repairs'
                    ? 'border-emerald-400 text-white'
                    : 'border-transparent text-emerald-200/70 hover:text-white'
                }`}
              >
                <Wrench className="w-4 h-4" />
                <span>Réparations SAV</span>
                <span className="bg-emerald-800 text-emerald-200 px-1.5 py-0.2 rounded-full text-[10px]">
                  {repairTariffs.length}
                </span>
              </button>

              <button
                onClick={() => setActiveBackendTab('print')}
                className={`py-3 px-2.5 font-bold border-b-2 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  activeBackendTab === 'print'
                    ? 'border-emerald-400 text-white'
                    : 'border-transparent text-emerald-200/70 hover:text-white'
                }`}
              >
                <Printer className="w-4 h-4" />
                <span>Tarifs Imprimerie</span>
              </button>

              <button
                onClick={() => setActiveBackendTab('money')}
                className={`py-3 px-2.5 font-bold border-b-2 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  activeBackendTab === 'money'
                    ? 'border-emerald-400 text-white'
                    : 'border-transparent text-emerald-200/70 hover:text-white'
                }`}
              >
                <Send className="w-4 h-4" />
                <span>Transfert d'argent</span>
                <span className="bg-emerald-800 text-emerald-200 px-1.5 py-0.2 rounded-full text-[10px]">
                  {moneyPartners.length}
                </span>
              </button>

              <button
                onClick={() => setActiveBackendTab('slider')}
                className={`py-3 px-2.5 font-bold border-b-2 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  activeBackendTab === 'slider'
                    ? 'border-emerald-400 text-white'
                    : 'border-transparent text-emerald-200/70 hover:text-white'
                }`}
              >
                <SlidersHorizontal className="w-4 h-4" />
                <span>Slider Posters</span>
                <span className="bg-emerald-800 text-emerald-200 px-1.5 py-0.2 rounded-full text-[10px]">
                  {sliderItems.length}
                </span>
              </button>

              <button
                onClick={() => setActiveBackendTab('settings')}
                className={`py-3 px-2.5 font-bold border-b-2 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  activeBackendTab === 'settings'
                    ? 'border-emerald-400 text-white'
                    : 'border-transparent text-emerald-200/70 hover:text-white'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Boutique & Infos</span>
              </button>

              <button
                onClick={() => setActiveBackendTab('categories')}
                className={`py-3 px-2.5 font-bold border-b-2 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  activeBackendTab === 'categories'
                    ? 'border-emerald-400 text-white'
                    : 'border-transparent text-emerald-200/70 hover:text-white'
                }`}
              >
                <Tag className="w-4 h-4" />
                <span>Catégories</span>
                <span className="bg-emerald-800 text-emerald-200 px-1.5 py-0.2 rounded-full text-[10px]">
                  {categories.length}
                </span>
              </button>

              <button
                onClick={() => setActiveBackendTab('audit')}
                className={`py-3 px-2.5 font-bold border-b-2 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  activeBackendTab === 'audit'
                    ? 'border-emerald-400 text-white'
                    : 'border-transparent text-emerald-200/70 hover:text-white'
                }`}
              >
                <History className="w-4 h-4" />
                <span>Journal d'audit</span>
                <span className="bg-emerald-800 text-emerald-200 px-1.5 py-0.2 rounded-full text-[10px]">
                  {auditLogs.length}
                </span>
              </button>

              <button
                onClick={() => setActiveBackendTab('admins')}
                className={`py-3 px-2.5 font-bold border-b-2 transition flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  activeBackendTab === 'admins'
                    ? 'border-emerald-400 text-white'
                    : 'border-transparent text-emerald-200/70 hover:text-white'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Comptes</span>
                <span className="bg-emerald-800 text-emerald-200 px-1.5 py-0.2 rounded-full text-[10px]">
                  {admins.length}
                </span>
              </button>
            </div>

            {/* Feedback Alert */}
            {feedback && (
              <div className="bg-emerald-600 text-white px-4 py-2 text-xs font-semibold flex items-center space-x-2 shrink-0 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{feedback}</span>
              </div>
            )}

            {/* Main Content Area based on Active Tab */}
            <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">

              {/* ============================================================ */}
              {/* TAB: CUSTOMER ORDERS & REQUESTS INBOX */}
              {/* ============================================================ */}
              {activeBackendTab === 'requests' && (
                <AdminRequestsView
                  requests={customerRequests}
                  onUpdateRequestStatus={onUpdateCustomerRequestStatus}
                  onDeleteRequest={onDeleteCustomerRequest}
                />
              )}

              {/* ============================================================ */}
              {/* TAB: REPAIRS & SAV ATELIER */}
              {/* ============================================================ */}
              {activeBackendTab === 'repairs' && (
                <AdminRepairsView
                  repairTariffs={repairTariffs}
                  onUpdateTariffs={onUpdateRepairTariffs}
                  onResetTariffs={onResetRepairTariffs || (() => {})}
                  adminRole={currentAdmin?.role || 'Super Admin'}
                  showFeedback={showFeedback}
                  logAuditAction={(action, summary, details) => logAudit(action as AuditActionType, summary, details)}
                />
              )}

              {/* ============================================================ */}
              {/* TAB: PRINT, PHOTOCOPY & DOCUMENT TARIFFS */}
              {/* ============================================================ */}
              {activeBackendTab === 'print' && (
                <AdminPrintPricingView
                  pricing={printPricing}
                  onUpdatePricing={onUpdatePrintPricing}
                  onResetPricing={onResetPrintPricing || (() => {})}
                  adminRole={currentAdmin?.role || 'Super Admin'}
                  showFeedback={showFeedback}
                  logAuditAction={(action, summary, details) => logAudit(action as AuditActionType, summary, details)}
                />
              )}

              {/* ============================================================ */}
              {/* TAB: MONEY TRANSFER & MOBILE RECHARGES */}
              {/* ============================================================ */}
              {activeBackendTab === 'money' && (
                <AdminMoneyTransferView
                  partners={moneyPartners}
                  onUpdatePartners={onUpdateMoneyPartners}
                  onResetPartners={onResetMoneyPartners || (() => {})}
                  adminRole={currentAdmin?.role || 'Super Admin'}
                  showFeedback={showFeedback}
                  logAuditAction={(action, summary, details) => logAudit(action as AuditActionType, summary, details)}
                />
              )}

              {/* ============================================================ */}
              {/* TAB: SLIDER POSTERS & HERO CAROUSEL */}
              {/* ============================================================ */}
              {activeBackendTab === 'slider' && (
                <AdminSliderView
                  slides={sliderItems}
                  onUpdateSlides={onUpdateSliderItems}
                  onResetSlides={onResetSliderItems || (() => {})}
                  adminRole={currentAdmin?.role || 'Super Admin'}
                  showFeedback={showFeedback}
                  logAuditAction={(action, summary, details) => logAudit(action as AuditActionType, summary, details)}
                />
              )}

              {/* ============================================================ */}
              {/* TAB: STORE SETTINGS & GENERAL COORDINATES */}
              {/* ============================================================ */}
              {activeBackendTab === 'settings' && (
                <AdminStoreSettingsView
                  settings={storeSettings}
                  onUpdateSettings={onUpdateStoreSettings}
                  onResetSettings={onResetStoreSettings || (() => {})}
                  adminRole={currentAdmin?.role || 'Super Admin'}
                  showFeedback={showFeedback}
                  logAuditAction={(action, summary, details) => logAudit(action as AuditActionType, summary, details)}
                />
              )}

              {/* ============================================================ */}
              {/* TAB: AUDIT TRAIL & ACTIVITY LOG */}
              {/* ============================================================ */}
              {activeBackendTab === 'audit' && (
                <AuditTrailView
                  logs={auditLogs}
                  admins={admins}
                  onClearLogs={() => {
                    setAuditLogs([]);
                    try {
                      localStorage.removeItem(AUDIT_LOGS_STORAGE_KEY);
                    } catch {}
                    showFeedback('Audit trail cleared.');
                  }}
                />
              )}

              {/* ============================================================ */}
              {/* TAB 3: ADMIN ACCOUNTS & PERMISSIONS */}
              {/* ============================================================ */}
              {activeBackendTab === 'admins' && (
                <AdminAccountsView
                  admins={admins}
                  currentAdmin={currentAdmin}
                  auditLogs={auditLogs}
                  onAddAdmin={handleAddAdminAccount}
                  onDeleteAdmin={handleDeleteAdminAccount}
                />
              )}

              {/* ============================================================ */}
              {/* TAB 4: CATEGORY CONFIGURATION */}
              {/* ============================================================ */}
              {activeBackendTab === 'categories' && (
                <div className="space-y-5 animate-in fade-in duration-200">
                  <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-4 sm:p-5 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <h3 className="font-extrabold text-base text-emerald-950 flex items-center space-x-2">
                          <Tag className="w-4 h-4 text-emerald-800" />
                          <span>Rayons & Catégories ({categories.length})</span>
                        </h3>
                        <p className="text-xs text-emerald-700 mt-0.5">
                          Créez et gérez les rayons de classement de votre inventaire.
                        </p>
                      </div>
                    </div>

                    {categoryError && (
                      <div className="bg-red-50 text-red-700 border border-red-200 px-3 py-1.5 rounded-xl text-xs">
                        {categoryError}
                      </div>
                    )}

                    <form onSubmit={handleAddCategorySubmit} className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="text"
                        placeholder="ex. Montres connectées, Accessoires gaming, Périphériques..."
                        value={newCategoryName}
                        onChange={(e) => setNewCategoryName(e.target.value)}
                        className="flex-1 px-3.5 py-2 text-xs bg-white border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3f704d]"
                      />
                      <button
                        type="submit"
                        className="bg-[#3f704d] hover:bg-[#335c3f] text-white px-4 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1.5 shadow-xs cursor-pointer"
                      >
                        <FolderPlus className="w-4 h-4" />
                        <span>Ajouter un rayon</span>
                      </button>
                    </form>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
                      {categories.map((cat) => {
                        const count = products.filter((p) => p.category === cat).length;
                        return (
                          <div
                            key={cat}
                            className="bg-white border border-emerald-200 p-3 rounded-xl flex items-center justify-between shadow-2xs"
                          >
                            <div>
                              <p className="font-bold text-gray-900 text-xs">{cat}</p>
                              <p className="text-[10px] text-gray-500">{count} produit{count > 1 ? 's' : ''}</p>
                            </div>
                            {onDeleteCategory && (
                              <button
                                type="button"
                                onClick={() => {
                                  if (window.confirm(`Supprimer la catégorie "${cat}" ? Les articles resteront dans l'inventaire.`)) {
                                    handleDeleteCategoryWithLog(cat);
                                  }
                                }}
                                title={`Supprimer ${cat}`}
                                className="text-gray-400 hover:text-red-600 p-1 rounded-md transition cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* ============================================================ */}
              {/* TAB 1: PRODUCTS & INVENTORY MANAGEMENT */}
              {/* ============================================================ */}
              {activeBackendTab === 'products' && (
                <div className="space-y-6 animate-in fade-in duration-200">
                  
                  {/* Action Bar */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-gray-200 shadow-2xs">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={handleStartAdd}
                        className="bg-[#3f704d] hover:bg-[#335c3f] text-white px-4 py-2 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-xs cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>+ Ajouter un produit</span>
                      </button>

                      <button
                        onClick={handleResetCatalogWithLog}
                        title="Réinitialiser le catalogue avec les articles par défaut"
                        className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-2 rounded-xl text-xs font-medium transition flex items-center space-x-1.5 cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Réinitialiser</span>
                      </button>
                    </div>

                    {/* Filter and Search */}
                    <div className="flex items-center space-x-2 flex-wrap">
                      <div className="relative">
                        <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-gray-400" />
                        <input
                          type="text"
                          placeholder="Rechercher un article..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-8 pr-3 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#3f704d]"
                        />
                      </div>

                      <select
                        value={selectedCategory}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                        className="px-2.5 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#3f704d] text-gray-700 font-medium cursor-pointer"
                      >
                        <option value="All">Tous les rayons ({products.length})</option>
                        {categories.map((cat) => (
                          <option key={cat} value={cat}>
                            {cat}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Add / Edit Form Drawer */}
                  {(isAddingNew || editingProduct) && (
                    <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 sm:p-5 space-y-4 animate-in slide-in-from-top-2">
                      <div className="flex items-center justify-between border-b border-emerald-200 pb-3">
                        <h4 className="text-sm font-bold text-emerald-950 flex items-center space-x-2">
                          <Edit3 className="w-4 h-4 text-emerald-800" />
                          <span>{isAddingNew ? 'Ajouter un nouvel article au catalogue' : `Modifier : ${editingProduct?.name}`}</span>
                        </h4>
                        <button
                          onClick={() => {
                            setIsAddingNew(false);
                            setEditingProduct(null);
                          }}
                          className="text-gray-500 hover:text-gray-800 text-xs font-medium cursor-pointer"
                        >
                          Annuler
                        </button>
                      </div>

                      <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          <div className="sm:col-span-2">
                            <label className="block font-semibold text-gray-700 mb-1">Nom / Référence du produit *</label>
                            <input
                              type="text"
                              required
                              value={formName}
                              onChange={(e) => setFormName(e.target.value)}
                              placeholder="ex. Apple iPhone 15 / 128 Go"
                              className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3f704d]"
                            />
                          </div>

                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <label className="block font-semibold text-gray-700">Rayon / Catégorie *</label>
                              <button
                                type="button"
                                onClick={() => setIsQuickAddingCat(!isQuickAddingCat)}
                                className="text-[10px] text-[#3f704d] hover:underline font-bold"
                              >
                                {isQuickAddingCat ? 'Choisir' : '+ Nouveau rayon'}
                              </button>
                            </div>

                            {isQuickAddingCat ? (
                              <div className="flex space-x-1">
                                <input
                                  type="text"
                                  placeholder="Nouveau rayon..."
                                  value={quickCatInput}
                                  onChange={(e) => setQuickCatInput(e.target.value)}
                                  className="w-full px-2 py-1.5 bg-white border border-gray-300 rounded-lg text-xs"
                                />
                                <button
                                  type="button"
                                  onClick={handleQuickAddCategory}
                                  className="bg-[#3f704d] text-white px-2 py-1 rounded-lg text-[10px] font-bold"
                                >
                                  OK
                                </button>
                              </div>
                            ) : (
                              <select
                                value={formCategory}
                                onChange={(e) => setFormCategory(e.target.value)}
                                className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3f704d] cursor-pointer"
                              >
                                {categories.map((c) => (
                                  <option key={c} value={c}>
                                    {c}
                                  </option>
                                ))}
                              </select>
                            )}
                          </div>

                          <div>
                            <label className="block font-semibold text-gray-700 mb-1">Marque *</label>
                            <input
                              type="text"
                              required
                              value={formBrand}
                              onChange={(e) => setFormBrand(e.target.value)}
                              placeholder="Apple, Samsung, JBL..."
                              className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3f704d]"
                            />
                          </div>

                          <div>
                            <label className="block font-semibold text-gray-700 mb-1">Prix de vente (€ TTC) *</label>
                            <input
                              type="number"
                              step="0.01"
                              required
                              min="0"
                              value={formPrice}
                              onChange={(e) => setFormPrice(Number(e.target.value))}
                              className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3f704d]"
                            />
                          </div>

                          <div>
                            <label className="block font-semibold text-gray-700 mb-1">Prix d'origine (€ barré, facultatif)</label>
                            <input
                              type="number"
                              step="0.01"
                              min="0"
                              value={formOriginalPrice}
                              onChange={(e) => setFormOriginalPrice(Number(e.target.value))}
                              className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3f704d]"
                            />
                          </div>

                          <div>
                            <label className="block font-semibold text-gray-700 mb-1">Quantité en stock *</label>
                            <input
                              type="number"
                              required
                              min="0"
                              value={formStock}
                              onChange={(e) => setFormStock(Number(e.target.value))}
                              className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3f704d]"
                            />
                          </div>

                          <div>
                            <label className="block font-semibold text-gray-700 mb-1">Garantie</label>
                            <input
                              type="text"
                              value={formWarranty}
                              onChange={(e) => setFormWarranty(e.target.value)}
                              placeholder="Garantie magasin 12 mois"
                              className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3f704d]"
                            />
                          </div>

                          <div>
                            <label className="block font-semibold text-gray-700 mb-1">URL de l'image principale</label>
                            <input
                              type="url"
                              value={formImage}
                              onChange={(e) => setFormImage(e.target.value)}
                              placeholder="https://..."
                              className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3f704d]"
                            />
                          </div>

                          <div>
                            <label className="block font-semibold text-gray-700 mb-1">État du produit</label>
                            <input
                              type="text"
                              value={formCondition}
                              onChange={(e) => setFormCondition(e.target.value)}
                              placeholder="ex. Neuf sous blister ou Reconditionné certifié (Grade A+)"
                              className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3f704d]"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block font-semibold text-gray-700 mb-1">
                            Galerie multi-photos (Une URL par ligne ou séparée par une virgule)
                          </label>
                          <textarea
                            rows={2}
                            value={formGalleryImages}
                            onChange={(e) => setFormGalleryImages(e.target.value)}
                            placeholder="https://images.unsplash.com/...&#10;https://images.unsplash.com/..."
                            className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3f704d] font-mono text-[11px]"
                          />
                          <span className="text-[10px] text-gray-400">
                            Ajoutez plusieurs vues de face, dos, écran, connectique. La première photo sert de visuel principal.
                          </span>
                        </div>

                        <div>
                          <label className="block font-semibold text-gray-700 mb-1">Résumé court</label>
                          <input
                            type="text"
                            value={formDescription}
                            onChange={(e) => setFormDescription(e.target.value)}
                            placeholder="Courte présentation de 1 à 2 phrases affichée sur la carte du catalogue..."
                            className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3f704d]"
                          />
                        </div>

                        <div>
                          <label className="block font-semibold text-gray-700 mb-1">Description complète & détaillée</label>
                          <textarea
                            rows={3}
                            value={formLongDescription}
                            onChange={(e) => setFormLongDescription(e.target.value)}
                            placeholder="Présentation exhaustive du modèle, des fonctionnalités, des performances, de l'état technique et des modalités de retrait..."
                            className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3f704d]"
                          />
                        </div>

                        <div>
                          <label className="block font-semibold text-gray-700 mb-1">Caractéristiques techniques (séparées par une virgule)</label>
                          <input
                            type="text"
                            value={formSpecs}
                            onChange={(e) => setFormSpecs(e.target.value)}
                            placeholder="ex. Écran OLED, Charge rapide 20W, Stockage 128 Go, Connectivité 5G"
                            className="w-full px-3 py-2 bg-white border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#3f704d]"
                          />
                        </div>

                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="featuredCheck"
                            checked={formFeatured}
                            onChange={(e) => setFormFeatured(e.target.checked)}
                            className="rounded text-[#3f704d] focus:ring-[#3f704d] accent-[#3f704d]"
                          />
                          <label htmlFor="featuredCheck" className="text-gray-700 font-medium cursor-pointer">
                            Mettre ce produit en avant dans la vitrine
                          </label>
                        </div>

                        <div className="flex items-center justify-end space-x-2 pt-2">
                          <button
                            type="button"
                            onClick={() => {
                              setIsAddingNew(false);
                              setEditingProduct(null);
                            }}
                            className="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer"
                          >
                            Annuler
                          </button>
                          <button
                            type="submit"
                            className="bg-[#3f704d] hover:bg-[#335c3f] text-white px-5 py-2 rounded-xl text-xs font-bold shadow-xs cursor-pointer flex items-center space-x-1.5"
                          >
                            <Save className="w-3.5 h-3.5" />
                            <span>{isAddingNew ? 'Enregistrer le produit' : 'Enregistrer les modifications'}</span>
                          </button>
                        </div>
                      </form>
                    </div>
                  )}

                  {/* Products Table */}
                  <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-xs">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-gray-50 text-gray-600 font-semibold border-b border-gray-200">
                          <tr>
                            <th className="p-3">Produit</th>
                            <th className="p-3">Rayon</th>
                            <th className="p-3">Marque</th>
                            <th className="p-3">Prix (€)</th>
                            <th className="p-3">Stock</th>
                            <th className="p-3">Garantie</th>
                            <th className="p-3 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                          {filteredProducts.map((p) => (
                            <tr key={p.id} className="hover:bg-emerald-50/40 transition">
                              <td className="p-3 flex items-center space-x-2.5">
                                <img
                                  src={p.image}
                                  alt={p.name}
                                  className="w-9 h-9 rounded-lg object-cover border border-gray-200 shrink-0"
                                  onError={(e) => {
                                    (e.target as HTMLImageElement).src =
                                      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=400&q=80';
                                  }}
                                />
                                <div>
                                  <p className="font-bold text-gray-900 leading-tight">{p.name}</p>
                                  {p.featured && (
                                    <span className="text-[9px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded font-semibold">
                                      En vedette
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="p-3 text-gray-600">{p.category}</td>
                              <td className="p-3 font-medium text-gray-800">{p.brand}</td>
                              <td className="p-3 font-bold text-emerald-950">{p.price.toFixed(2).replace('.', ',')} €</td>
                              <td className="p-3">
                                <span
                                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                    p.stock > 0
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : 'bg-red-100 text-red-800'
                                  }`}
                                >
                                  {p.stock > 0 ? `${p.stock} en stock` : 'Rupture'}
                                </span>
                              </td>
                              <td className="p-3 text-gray-500 text-[11px]">{p.warranty}</td>
                              <td className="p-3 text-right">
                                <div className="inline-flex items-center space-x-1">
                                  <button
                                    onClick={() => handleStartEdit(p)}
                                    title="Modifier le produit"
                                    className="p-1.5 text-gray-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition cursor-pointer"
                                  >
                                    <Edit3 className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={() => handleDeleteProductWithLog(p)}
                                    title="Supprimer le produit"
                                    className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition cursor-pointer"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              )}

            </div>
          </>
        )}

      </div>
    </div>
  );
};
