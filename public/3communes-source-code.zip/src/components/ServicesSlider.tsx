import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ActiveTab, ServiceSlideItem } from '../types';
import { 
  ArrowLeftRight, 
  ShoppingBag, 
  Wrench, 
  Copy, 
  FileCheck2, 
  Wifi, 
  ArrowRight, 
  ChevronLeft, 
  ChevronRight, 
  Pause, 
  Play, 
  CheckCircle2,
  Sparkles,
  ShieldCheck
} from 'lucide-react';

interface ServicesSliderProps {
  setActiveTab: (tab: ActiveTab) => void;
  slides?: ServiceSlideItem[];
}

interface ServiceSlide {
  id: string;
  number: string;
  title: string;
  tagline: string;
  tag: string;
  description: string;
  highlights: string[];
  image: string;
  actionText: string;
  actionTab: ActiveTab;
  icon: React.ReactNode;
}

const SERVICES_SLIDES: ServiceSlide[] = [
  {
    id: 'money',
    number: '01',
    title: "Transfert d'argent & recharges mobiles",
    tagline: "Envoyez et recevez de l'argent dans le monde entier aux meilleurs taux",
    tag: "Western Union • Ria • MoneyGram",
    description: "Partenaire officiel agréé pour vos transferts internationaux immédiats et recharges d'unités mobiles (Orange Money, Ding, Joxko, SFR, Bouygues, Free). Taux interbancaires en direct et reçu officiel au comptoir.",
    highlights: [
      "Taux de change en direct Google / Interbancaire",
      "Retrait espèces immédiat & dépôt bancaire",
      "Reçu officiel et transaction sécurisée"
    ],
    image: "/assets/images/money_transfer.jpg",
    actionText: "Simuler un envoi d'argent",
    actionTab: 'money',
    icon: <ArrowLeftRight className="w-5 h-5" />
  },
  {
    id: 'phones',
    number: '02',
    title: "Smartphones, Informatique & Accessoires",
    tagline: "Appareils neufs et reconditionnés certifiés avec garantie magasin",
    tag: "Apple • Samsung • Xiaomi • PC & Audio",
    description: "Vente d'iPhones, Samsung Galaxy, Xiaomi et téléphones à touches. Grand choix de coques antichocs, verres trempés 9H avec pose offerte, chargeurs GaN, câbles tressés et écouteurs Bluetooth.",
    highlights: [
      "Garantie magasin de 12 à 24 mois sur les téléphones",
      "Pose de protection écran 9H offerte sur place",
      "Accessoires certifiés, audio et connectique haute vitesse"
    ],
    image: "/assets/images/phones_accessories.jpg",
    actionText: "Consulter le catalogue produits",
    actionTab: 'accessories',
    icon: <ShoppingBag className="w-5 h-5" />
  },
  {
    id: 'repairs',
    number: '03',
    title: "Réparation express & déblocage réseau",
    tagline: "Prise en charge immédiate au comptoir de Romainville en 30 minutes",
    tag: "Atelier SAV Romainville • 30 Minutes",
    description: "Remplacement d'écrans cassés, batteries affaiblies, connecteurs de charge, haut-parleurs, désoxydation après contact avec l'eau et désimlockage définitif tout opérateur.",
    highlights: [
      "Diagnostic gratuit et réparation sans rendez-vous en 30 min",
      "Pièces détachées rigoureusement testées et garanties",
      "Désimlockage permanent pour tout opérateur dans le monde"
    ],
    image: "/assets/images/phone_repair.jpg",
    actionText: "Estimer une réparation",
    actionTab: 'repairs',
    icon: <Wrench className="w-5 h-5" />
  },
  {
    id: 'printing',
    number: '04',
    title: "Photocopie, impression & numérisation",
    tagline: "Reprographie professionnelle et tirages express haute fidélité",
    tag: "Tirage Noir & Blanc & Couleur HD • A4 / A3",
    description: "Imprimez vos dossiers, CV, thèses, rapports, contrats et formulaires administratifs en noir & blanc ou couleur HD. Impression directe depuis clé USB, e-mail ou smartphone.",
    highlights: [
      "Tarifs transparents : N&B dès 0,15 € / Couleur HD dès 0,40 €",
      "Impression instantanée depuis USB, smartphone ou e-mail",
      "Numérisation HD de documents vers e-mail ou clé USB"
    ],
    image: "/assets/images/document_printing.jpg",
    actionText: "Simulateur de tarifs d'impression",
    actionTab: 'print',
    icon: <Copy className="w-5 h-5" />
  },
  {
    id: 'lamination',
    number: '05',
    title: "Plastification de documents & fax",
    tagline: "Protection thermique rigide et service de télécopie avec accusé officiel",
    tag: "Protection thermique rigide A4 / A3",
    description: "Protégez durablement vos diplômes, certificats, contrats et cartes contre l'usure et l'eau avec nos pochettes thermiques rigides et brillantes. Envois et réceptions de fax en France et à l'international.",
    highlights: [
      "Pochettes thermiques rigides imperméables et anti-déchirure",
      "Formats A4, A3, cartes professionnelles et badges",
      "Envoi et réception de télécopies avec accusé de transmission"
    ],
    image: "/assets/images/document_lamination.jpg",
    actionText: "Découvrir la plastification & fax",
    actionTab: 'print',
    icon: <FileCheck2 className="w-5 h-5" />
  },
  {
    id: 'cyber',
    number: '06',
    title: "Postes internet & démarches en ligne",
    tagline: "Espace informatique connecté à la fibre très haut débit",
    tag: "Fibre Très Haut Débit • Démarches administratives",
    description: "Postes informatiques individuels et sécurisés pour toutes vos démarches administratives (CAF, Ameli, ANTS, Pôle Emploi, impôts), réservations de billets, CV et navigation internet avec imprimante reliée.",
    highlights: [
      "Fibre très haut débit avec postes individuels calmes",
      "Accompagnement et aide de notre équipe au comptoir",
      "Confidentialité garantie : aucune donnée personnelle conservée"
    ],
    image: "/assets/images/cyber_internet.jpg",
    actionText: "Accéder aux postes internet",
    actionTab: 'services',
    icon: <Wifi className="w-5 h-5" />
  }
];

export const ServicesSlider: React.FC<ServicesSliderProps> = ({ setActiveTab, slides }) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [touchStartX, setTouchStartX] = useState<number | null>(null);
  const [touchEndX, setTouchEndX] = useState<number | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const SLIDE_INTERVAL_MS = 5000;

  const getIconForTab = (tab: ActiveTab) => {
    switch (tab) {
      case 'money': return <ArrowLeftRight className="w-5 h-5" />;
      case 'accessories': return <ShoppingBag className="w-5 h-5" />;
      case 'repairs': return <Wrench className="w-5 h-5" />;
      case 'print': return <Copy className="w-5 h-5" />;
      case 'services': return <Wifi className="w-5 h-5" />;
      default: return <FileCheck2 className="w-5 h-5" />;
    }
  };

  const sanitizeImageUrl = (url: string | undefined): string => {
    if (!url) return '/assets/images/phones_accessories.jpg';
    if (url.startsWith('/src/assets/images/')) {
      return url.replace('/src/assets/images/', '/assets/images/');
    }
    return url;
  };

  const activeSlidesList = (slides && slides.length > 0 ? slides : SERVICES_SLIDES).map((s, idx) => ({
    ...s,
    image: sanitizeImageUrl(s.image),
    number: s.number || (idx + 1 < 10 ? `0${idx + 1}` : `${idx + 1}`),
    highlights: s.highlights || [],
    icon: getIconForTab(s.actionTab)
  }));

  const safeIndex = currentIndex >= activeSlidesList.length ? 0 : currentIndex;
  const currentSlide = activeSlidesList[safeIndex];

  const nextSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % activeSlidesList.length);
  }, [activeSlidesList.length]);

  const prevSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + activeSlidesList.length) % activeSlidesList.length);
  }, [activeSlidesList.length]);

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  // Autoplay management
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        nextSlide();
      }, SLIDE_INTERVAL_MS);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, nextSlide, currentIndex]);

  // Touch handlers for mobile swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStartX(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEndX(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStartX || !touchEndX) return;
    const distance = touchStartX - touchEndX;
    const minSwipeDistance = 50;
    if (distance > minSwipeDistance) {
      nextSlide();
    } else if (distance < -minSwipeDistance) {
      prevSlide();
    }
    setTouchStartX(null);
    setTouchEndX(null);
  };

  return (
    <section className="space-y-4">
      {/* Section Header with Quick Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="inline-flex items-center space-x-1.5 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>Vitrine Officielle • 3 Communes Informatique</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-gray-900 tracking-tight">
            Tous nos services en boutique
          </h2>
        </div>

        {/* Play/Pause & Prev/Next Controls */}
        <div className="flex items-center space-x-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-2 rounded-xl bg-white border border-gray-200 text-gray-700 hover:text-emerald-800 hover:border-emerald-300 transition shadow-2xs cursor-pointer flex items-center space-x-1.5 text-xs font-semibold"
            title={isPlaying ? "Mettre en pause le défilement" : "Reprendre le défilement automatique"}
          >
            {isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Pause</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 text-emerald-700" />
                <span className="hidden sm:inline">Lecture</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={prevSlide}
            className="p-2 rounded-xl bg-white border border-gray-200 text-gray-700 hover:text-emerald-800 hover:border-emerald-300 transition shadow-2xs cursor-pointer"
            title="Service précédent"
            aria-label="Service précédent"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <span className="text-xs font-bold text-gray-700 px-1 min-w-[48px] text-center">
            {currentIndex + 1} / {SERVICES_SLIDES.length}
          </span>

          <button
            type="button"
            onClick={nextSlide}
            className="p-2 rounded-xl bg-white border border-gray-200 text-gray-700 hover:text-emerald-800 hover:border-emerald-300 transition shadow-2xs cursor-pointer"
            title="Service suivant"
            aria-label="Service suivant"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* FULL LANDSCAPE PROFESSIONAL POSTER BANNER */}
      <div 
        className="relative w-full rounded-3xl overflow-hidden shadow-xl border border-emerald-200/90 bg-gray-950 group select-none min-h-[460px] sm:min-h-[500px] lg:min-h-[520px] flex flex-col justify-between"
        onMouseEnter={() => setIsPlaying(false)}
        onMouseLeave={() => setIsPlaying(true)}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Full Landscape Background Image */}
        <div className="absolute inset-0 w-full h-full">
          <img
            key={currentSlide.id}
            src={currentSlide.image}
            alt={currentSlide.title}
            loading="eager"
            decoding="async"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center transform transition-all duration-700 ease-out group-hover:scale-105"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              if (!target.src.endsWith('phones_accessories.jpg')) {
                target.src = '/assets/images/phones_accessories.jpg';
              }
            }}
          />

          {/* Balanced Responsive Scrim: Allows background picture to be clearly visible on mobile without being drowned in black */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-black/25 sm:bg-gradient-to-r sm:from-black/90 sm:via-black/65 sm:to-black/20"></div>
          <div className="absolute inset-0 bg-black/20 sm:hidden"></div>
        </div>

        {/* POSTER HEADER (Overlaid inside picture) */}
        <div className="relative z-10 p-5 sm:p-8 flex items-center justify-between gap-3">
          <div className="flex items-center space-x-2.5 flex-wrap gap-y-2">
            <span className="bg-emerald-950/80 backdrop-blur-md text-emerald-300 border border-emerald-500/40 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider flex items-center space-x-1.5 shadow-sm">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>3 Communes Informatique</span>
            </span>

            <span className="bg-white/15 backdrop-blur-md text-white border border-white/20 px-3 py-1 rounded-full text-xs font-semibold">
              {currentSlide.tag}
            </span>
          </div>

          {/* Slide Indicator Badge */}
          <div className="bg-black/50 backdrop-blur-md border border-white/15 text-white px-3 py-1 rounded-xl text-xs font-mono font-bold tracking-widest hidden sm:flex items-center space-x-1">
            <span className="text-emerald-400">{currentSlide.number}</span>
            <span className="text-gray-400">/</span>
            <span>06</span>
          </div>
        </div>

        {/* POSTER MAIN CONTENT (Overlaid inside picture) */}
        <div className="relative z-10 px-5 sm:px-8 py-2 sm:py-4 max-w-3xl space-y-4">
          
          {/* Main Service Icon & Category Badge */}
          <div className="inline-flex items-center space-x-2 bg-emerald-500/20 backdrop-blur-md border border-emerald-400/40 text-emerald-300 px-3 py-1.5 rounded-2xl">
            <div className="p-1 rounded-lg bg-emerald-600 text-white">
              {currentSlide.icon}
            </div>
            <span className="text-xs font-bold tracking-wide">
              Service en boutique • Romainville 93230
            </span>
          </div>

          {/* Bold Poster Headline */}
          <h3 className="text-2xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight drop-shadow-md">
            {currentSlide.title}
          </h3>

          {/* Tagline / Subtitle */}
          <p className="text-sm sm:text-base font-semibold text-emerald-300 drop-shadow-xs">
            {currentSlide.tagline}
          </p>

          {/* Description */}
          <p className="text-xs sm:text-sm text-gray-200 leading-relaxed max-w-2xl drop-shadow-xs">
            {currentSlide.description}
          </p>

          {/* 3 Key Guarantee / Feature Pills inside Poster */}
          <div className="flex flex-wrap gap-2 pt-1">
            {currentSlide.highlights.map((item, idx) => (
              <div 
                key={idx}
                className="inline-flex items-center space-x-1.5 bg-black/40 backdrop-blur-md border border-white/20 text-gray-100 text-[11px] sm:text-xs font-medium px-3 py-1.5 rounded-xl shadow-xs"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>{item}</span>
              </div>
            ))}
          </div>

          {/* Poster Call to Action Button */}
          <div className="pt-2 flex items-center space-x-3 flex-wrap gap-y-2">
            <button
              type="button"
              onClick={() => setActiveTab(currentSlide.actionTab)}
              className="bg-[#3f704d] hover:bg-[#335c3f] text-white font-bold py-3 px-6 rounded-2xl text-xs sm:text-sm shadow-lg transition active:scale-98 flex items-center space-x-2 cursor-pointer border border-emerald-400/30"
            >
              <span>{currentSlide.actionText}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <span className="text-xs text-gray-300 flex items-center space-x-1.5 bg-black/30 backdrop-blur-sm px-3 py-2 rounded-xl">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Accueil & comptoir ouvert 7j/7</span>
            </span>
          </div>

        </div>

        {/* POSTER FOOTER (Bottom bar overlaid inside picture with progress & dots) */}
        <div className="relative z-10 p-5 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-white/10 bg-black/30 backdrop-blur-xs">
          
          {/* Quick info note */}
          <div className="text-[11px] text-gray-300 font-medium text-center sm:text-left">
            4-6 boulevard de la Boissière, 93230 Romainville • 01.43.93.16.79
          </div>

          {/* Clickable Dots Navigation */}
          <div className="flex items-center space-x-2">
            {SERVICES_SLIDES.map((slide, idx) => (
              <button
                key={slide.id}
                type="button"
                onClick={() => goToSlide(idx)}
                className={`h-2.5 rounded-full transition-all duration-300 cursor-pointer ${
                  currentIndex === idx 
                    ? 'w-8 bg-emerald-400 shadow-xs' 
                    : 'w-2.5 bg-white/40 hover:bg-white/70'
                }`}
                title={`Afficher le pôle : ${slide.title}`}
                aria-label={`Aller au slide ${idx + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Large Floating Side Navigation Arrows */}
        <button
          type="button"
          onClick={prevSlide}
          className="absolute left-3 sm:left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-black/40 hover:bg-black/75 text-white backdrop-blur-md border border-white/20 flex items-center justify-center transition shadow-lg cursor-pointer"
          title="Précédent"
          aria-label="Slide précédent"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <button
          type="button"
          onClick={nextSlide}
          className="absolute right-3 sm:right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-black/40 hover:bg-black/75 text-white backdrop-blur-md border border-white/20 flex items-center justify-center transition shadow-lg cursor-pointer"
          title="Suivant"
          aria-label="Slide suivant"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      {/* USER CHOOSER BAR: Clean Interactive Selector Cards below poster */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 pt-1">
        {activeSlidesList.map((slide, idx) => {
          const isSelected = currentIndex === idx;
          return (
            <button
              key={slide.id}
              type="button"
              onClick={() => goToSlide(idx)}
              className={`p-3 rounded-2xl border text-left transition-all duration-200 flex flex-col justify-between cursor-pointer ${
                isSelected
                  ? 'border-[#3f704d] bg-emerald-50/90 ring-2 ring-[#3f704d]/25 shadow-xs'
                  : 'border-gray-200 bg-white hover:border-emerald-200 hover:bg-emerald-50/30'
              }`}
            >
              <div className="flex items-center justify-between w-full mb-1.5">
                <div className={`p-1.5 rounded-lg ${isSelected ? 'bg-[#3f704d] text-white' : 'bg-emerald-50 text-emerald-800'}`}>
                  {slide.icon}
                </div>
                <span className={`text-[10px] font-bold ${isSelected ? 'text-[#3f704d]' : 'text-gray-400'}`}>
                  {slide.number}
                </span>
              </div>
              <div className="space-y-0.5">
                <p className={`text-xs font-bold leading-tight ${isSelected ? 'text-emerald-950 font-extrabold' : 'text-gray-800'}`}>
                  {slide.title}
                </p>
                <p className="text-[10px] text-gray-500 truncate">
                  {slide.tag}
                </p>
              </div>
            </button>
          );
        })}
      </div>

    </section>
  );
};
