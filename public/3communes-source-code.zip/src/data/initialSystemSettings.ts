import { 
  RepairServiceTariff, 
  PrintPricingSettings, 
  MoneyTransferPartner, 
  StoreSettings, 
  ServiceSlideItem 
} from '../types';

export const INITIAL_REPAIR_TARIFFS: RepairServiceTariff[] = [
  {
    id: 'rep-1',
    name: "Remplacement d'écran / vitre OLED",
    price: 'À partir de 49 €',
    numericPrice: 49,
    time: '30 à 45 min',
    warranty: 'Garantie 6 mois',
    deviceType: 'iPhone & Android',
    description: 'Pose d\'écran haute définition OLED/LCD certifié avec transfert TrueTone et calibration tactile.',
    active: true
  },
  {
    id: 'rep-2',
    name: 'Remplacement de batterie',
    price: 'À partir de 35 €',
    numericPrice: 35,
    time: '20 à 30 min',
    warranty: 'Garantie 6 mois',
    deviceType: 'Tous modèles',
    description: 'Batterie neuve haute capacité grade AAA avec cycle zéro et santé 100%.',
    active: true
  },
  {
    id: 'rep-3',
    name: 'Connecteur de charge / Port USB-C',
    price: 'À partir de 39 €',
    numericPrice: 39,
    time: '30 min',
    warranty: 'Garantie 6 mois',
    deviceType: 'Tous modèles',
    description: 'Remplacement de la nappe de charge ou désobstruction approfondie en cas de faux contact.',
    active: true
  },
  {
    id: 'rep-4',
    name: 'Désimlockage réseau / Déblocage tout opérateur',
    price: 'À partir de 20 €',
    numericPrice: 20,
    time: '15 à 30 min',
    warranty: 'Déblocage permanent',
    deviceType: 'Tous opérateurs',
    description: 'Désimlockage définitif officiel tout opérateur (Orange, SFR, Bouygues, Free, international).',
    active: true
  },
  {
    id: 'rep-5',
    name: 'Réinitialisation compte & code de verrouillage',
    price: 'À partir de 25 €',
    numericPrice: 25,
    time: '30 à 60 min',
    warranty: 'Service garanti',
    deviceType: 'Android & iOS',
    description: 'Remise à zéro d\'usine sur présentation de justificatif d\'achat, suppression des blocages logiciels.',
    active: true
  },
  {
    id: 'rep-6',
    name: 'Désoxydation bain à ultrasons (téléphone tombé dans l\'eau)',
    price: '35 € forfait diagnostic',
    numericPrice: 35,
    time: '2 à 3 heures',
    warranty: 'Bain ultrasons',
    deviceType: 'Tous appareils',
    description: 'Démontage complet, passage en cuve à ultrasons avec solvant désoxydant spécialisé et séchage thermique.',
    active: true
  },
  {
    id: 'rep-7',
    name: 'Réparation caméra avant / arrière',
    price: 'À partir de 40 €',
    numericPrice: 40,
    time: '40 min',
    warranty: 'Garantie 6 mois',
    deviceType: 'iPhone & Android',
    description: 'Changement de capteur photo flou, lentille cassée ou stabilisateur optique défaillant.',
    active: true
  },
  {
    id: 'rep-8',
    name: 'Haut-parleur & écouteur d\'appel',
    price: 'À partir de 30 €',
    numericPrice: 30,
    time: '30 min',
    warranty: 'Garantie 6 mois',
    deviceType: 'Tous modèles',
    description: 'Restauration du son grésillant, micro muet ou écouteur interne inaudible lors des conversations.',
    active: true
  }
];

export const INITIAL_PRINT_PRICING: PrintPricingSettings = {
  bwA4: 0.15,
  bwA3: 0.30,
  colorA4: 0.40,
  colorA3: 0.80,
  laminationA4: 2.00,
  scanPerPage: 0.30,
  faxPerPage: 1.50,
  internetHourlyRate: 2.50,
  bindingPerPage: 3.50
};

export const INITIAL_MONEY_PARTNERS: MoneyTransferPartner[] = [
  {
    id: 'partner-wu',
    name: 'Western Union',
    feeFrom: 'À partir de 1,90 €',
    speed: 'Immédiat (quelques minutes)',
    description: 'Réseau mondial de plus de 500 000 agences. Retrait en espèces ou virement direct sur compte bancaire.',
    active: true
  },
  {
    id: 'partner-ria',
    name: 'Ria Money Transfer',
    feeFrom: 'À partir de 1,50 €',
    speed: 'Immédiat au guichet',
    description: 'Taux de change compétitifs vers l\'Afrique, l\'Asie, l\'Amérique Latine et l\'Europe.',
    active: true
  },
  {
    id: 'partner-mg',
    name: 'MoneyGram',
    feeFrom: 'À partir de 1,90 €',
    speed: 'Instantané',
    description: 'Envoi sécurisé vers comptes bancaires et portefeuilles mobiles dans plus de 200 pays.',
    active: true
  },
  {
    id: 'partner-om',
    name: 'Orange Money',
    feeFrom: 'Sans frais cachés',
    speed: 'Instantané sur mobile',
    description: 'Recharges et transferts directs vers les portefeuilles Orange Money en Afrique de l\'Ouest et Centrale.',
    active: true
  },
  {
    id: 'partner-ding',
    name: 'Ding',
    feeFrom: 'Dès 1 € de recharge',
    speed: 'Instantané',
    description: 'Recharges de crédit de communication et données internet vers plus de 150 pays.',
    active: true
  },
  {
    id: 'partner-joxko',
    name: 'Joxko',
    feeFrom: 'Taux direct',
    speed: 'Directement au numéro',
    description: 'Envoi d\'unités de recharges téléphoniques internationales immédiates.',
    active: true
  }
];

export const INITIAL_STORE_SETTINGS: StoreSettings = {
  storeName: '3 Communes Informatique',
  streetAddress: '4-6 boulevard de la Boissière',
  cityZip: '93230 Romainville, France',
  phone: '01.43.93.16.79',
  whatsapp: '+33 7 58 46 47 62',
  email: '3communesinfo@gmail.com',
  openingHours: 'Ouvert 7 jours sur 7 (09:00 - 20:00)',
  announcementBanner: 'Ouvert 7j/7 sans interruption • Transferts d\'argent & réparations express en 30 min',
  announcementActive: false,
  warrantyInfo: 'Jusqu\'à 24 mois de garantie magasin sur produits & réparations',
  transitInfo: 'Lignes de bus 129, 318, 105 • Dépose-minute gratuit devant la boutique'
};

export const INITIAL_SLIDER_ITEMS: ServiceSlideItem[] = [
  {
    id: 'money',
    number: '01',
    title: "Transfert d'argent & recharges mobiles",
    tagline: "Envoyez et recevez de l'argent dans le monde entier aux meilleurs taux",
    tag: "Western Union • Ria • MoneyGram",
    description: "Partenaire officiel agréé pour vos transferts internationaux immédiats et recharges d'unités mobiles (Orange Money, Ding, Joxko, SFR, Bouygues, Free). Taux interbancaires en direct et reçu officiel au comptoir.",
    highlights: [
      "Taux de change en direct Google / Interbancaire",
      "Retrait espèces immédiat & dépôt bancaire",
      "Reçu officiel et transaction sécurisée"
    ],
    image: "/assets/images/money_transfer.jpg",
    actionText: "Simuler un envoi d'argent",
    actionTab: 'money'
  },
  {
    id: 'phones',
    number: '02',
    title: "Smartphones, Informatique & Accessoires",
    tagline: "Appareils neufs et reconditionnés certifiés avec garantie magasin",
    tag: "Apple • Samsung • Xiaomi • PC",
    description: "iPhone, Samsung Galaxy, Xiaomi, coques de protection renforcées, verres trempés 9H avec pose offerte en boutique, chargeurs rapides GaN et périphériques informatiques prêts à l'emploi.",
    highlights: [
      "Garantie magasin jusqu'à 24 mois",
      "Pose offerte des protections écran",
      "Reprise & devis gratuit sur place"
    ],
    image: "/assets/images/phones_accessories.jpg",
    actionText: "Voir le catalogue produits",
    actionTab: 'accessories'
  },
  {
    id: 'repairs',
    number: '03',
    title: "Réparation express & déblocage réseau",
    tagline: "Écran, batterie, connecteur réparés en 30 minutes sans rendez-vous",
    tag: "Toutes marques • Pièces garanties",
    description: "Remplacement d'écrans cassés, batteries affaiblies, connecteurs de charge, haut-parleurs, désoxydation après contact avec l'eau et désimlockage définitif tout opérateur.",
    highlights: [
      "Intervention en 30 minutes sans rendez-vous",
      "Pièces certifiées d'origine ou grade A",
      "Devis gratuit et transparent avant travaux"
    ],
    image: "/assets/images/phone_repair.jpg",
    actionText: "Estimer une réparation",
    actionTab: 'repairs'
  },
  {
    id: 'print',
    number: '04',
    title: "Photocopie, impression & numérisation",
    tagline: "Copies noir & blanc et couleur haute définition en libre-service assisté",
    tag: "A4 • A3 • Clé USB • Smartphone • E-mail",
    description: "Impression immédiate de vos dossiers, CV, mémoires, attestations et contrats depuis clé USB, smartphone ou boîte e-mail avec numérisation PDF haute définition.",
    highlights: [
      "Formats A4 et A3 en noir et blanc ou couleur",
      "Impression depuis smartphone, clé USB ou e-mail",
      "Numérisation haute résolution vers e-mail ou clé"
    ],
    image: "/assets/images/document_printing.jpg",
    actionText: "Tarifs d'impression & devis",
    actionTab: 'print'
  },
  {
    id: 'lamination',
    number: '05',
    title: "Plastification de documents & fax",
    tagline: "Protection thermique rigide et transmissions sécurisées",
    tag: "Protection durable • Accusé de réception",
    description: "Plastification de documents pour une durabilité maximale contre l'usure et l'humidité. Envoi et réception de fax en France et à l'international avec remise d'un récépissé officiel.",
    highlights: [
      "Plastification thermique anti-usure et étanche",
      "Formats A4, A3, cartes et badges",
      "Envoi et réception de fax avec reçu"
    ],
    image: "/assets/images/document_lamination.jpg",
    actionText: "Consulter les options bureautique",
    actionTab: 'print'
  },
  {
    id: 'cyber',
    number: '06',
    title: "Postes internet & démarches en ligne",
    tagline: "Espace connecté fibre très haut débit pour vos démarches",
    tag: "Fibre optique • Confidentialité garantie",
    description: "Postes informatiques équipés avec connexion fibre optique sécurisée pour vos démarches administratives (CAF, Ameli, Pôle Emploi, ANTS), réservations de billets et rédaction de CV.",
    highlights: [
      "Accès internet fibre très haut débit",
      "Assistance bienveillante pour démarches",
      "Postes sécurisés avec effacement des données"
    ],
    image: "/assets/images/cyber_internet.jpg",
    actionText: "Découvrir l'espace informatique",
    actionTab: 'services'
  }
];
